#include "handler.h"

handler_list res_with() {
    return {
        // RES plugin has no addresses yet - placeholder
    };
}
