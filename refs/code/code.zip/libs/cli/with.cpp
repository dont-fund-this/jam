#include "handler.h"

handler_list cli_with() {
    return {
        // CLI plugin has no addresses yet - placeholder
    };
}
