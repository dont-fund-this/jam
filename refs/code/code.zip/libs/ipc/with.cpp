#include "handler.h"

handler_list ipc_with() {
    return {
        // IPC plugin has no addresses yet - placeholder
    };
}
