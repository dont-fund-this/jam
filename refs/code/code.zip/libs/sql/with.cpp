#include "handler.h"

handler_list sql_with() {
    return {
        // SQL plugin has no addresses yet - placeholder
    };
}
