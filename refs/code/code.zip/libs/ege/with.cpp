#include "handler.h"

handler_list ege_with() {
    return {
        // EGE plugin has no addresses yet - placeholder
    };
}
