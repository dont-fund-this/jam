#include "handler.h"

handler_list lua_with() {
    return {
        // LUA plugin has no addresses yet - placeholder
    };
}
