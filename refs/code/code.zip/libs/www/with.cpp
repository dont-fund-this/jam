#include "handler.h"

handler_list www_with() {
    return {
        // WWW plugin has no addresses yet - placeholder
    };
}
