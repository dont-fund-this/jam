#include "handler.h"

handler_list cmd_with() {
    return {
        // CMD plugin has no addresses yet - placeholder
    };
}
