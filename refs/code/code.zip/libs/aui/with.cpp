#include "handler.h"

handler_list aui_with() {
    return {
        // AUI plugin has no addresses yet - placeholder
    };
}
