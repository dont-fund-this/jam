#include "handler.h"

handler_list tui_with() {
    return {
        // TUI plugin has no addresses yet - placeholder
    };
}
