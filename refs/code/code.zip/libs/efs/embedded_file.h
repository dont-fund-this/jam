#pragma once

struct EmbeddedFile {
    const char* path;
    const unsigned char* data;
    unsigned int size;
};
