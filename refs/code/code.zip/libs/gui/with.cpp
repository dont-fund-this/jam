#include "handler.h"

handler_list gui_with() {
    return {
        // GUI plugin has no addresses yet - placeholder
    };
}
