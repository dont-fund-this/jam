
(async () => {
    console.debug('hey');
})();

