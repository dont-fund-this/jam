#pragma once

struct ControlFns;

const char* control_invoke(const ControlFns& fns);
