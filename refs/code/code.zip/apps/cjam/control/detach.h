#pragma once

struct ControlFns;

void control_detach(void* handle, const ControlFns& fns);
