#pragma once

void* control_find(char** argv);
