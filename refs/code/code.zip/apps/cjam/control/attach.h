#pragma once

struct ControlFns;

bool control_attach(void* handle, const ControlFns& fns);
