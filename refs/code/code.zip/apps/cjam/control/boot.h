#pragma once

void* control_boot(char** argv);
