#include <HsFFI.h>
#if defined(__cplusplus)
extern "C" {
#endif
extern void zdmainzdMainzdMainzuwrapInvokeFn(void *cif STG_UNUSED, void* resp, void** args, void* the_stableptr);
#if defined(__cplusplus)
}
#endif

